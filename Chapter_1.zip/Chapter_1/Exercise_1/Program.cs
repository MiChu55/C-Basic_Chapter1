﻿using System;

namespace Chapter_1
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //Exercise 1
            Console.WriteLine("---------- Exercise 1 ---------");
            string userInput;
            int a, b;

            Console.WriteLine("Enter a: ");
            userInput = Console.ReadLine();
            a = Convert.ToInt32(userInput);

            Console.WriteLine("Enter b: ");
            userInput = Console.ReadLine();
            b = Convert.ToInt32(userInput);

            Console.WriteLine("Sum of {0} and {1} is: {2}", a, b, a + b);
            Console.WriteLine("\n");

            //Exercise 2
            Console.WriteLine("---------- Exercise 2 ---------");
            string name, phone, gender;

            Console.WriteLine("Enter your name: ");
            name = Console.ReadLine();

            Console.WriteLine("Enter your phone number: ");
            phone = Console.ReadLine();

            Console.WriteLine("Enter F is Female or M is Male: ");
            gender = Console.ReadLine();

            Console.WriteLine("Name: {0} \nPhone number: {1}", name, phone);
            if (gender == "F" || gender == "f")
                Console.WriteLine("Gender: Female");
            else
                Console.WriteLine("Gender: Male");
            Console.WriteLine("\n");

            //Exercise 3
            Console.WriteLine("---------- Exercise 3 ---------");
            const double pi = 3.14;
            double rCircle = 0;
            Console.WriteLine("Radius is: ");
            userInput = Console.ReadLine();
            rCircle = Convert.ToDouble(userInput);
            Console.WriteLine("Diameter of circle is: {0}", pi * rCircle * 2);
        }
    }
}
